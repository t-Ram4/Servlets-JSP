package com.anathe.training.web;
import javax.servlet.http.*;  
import javax.servlet.*;  
import java.io.*; 
import javax.servlet.annotation.WebServlet;  

@WebServlet("/hello")  
public class WelcomeAnotherServlet extends HttpServlet{ 

 
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException  {  
	
	 System.out.println("Welcome to the world of Servlet");

	String name = req.getParameter("name");

	System.out.println("Hello "+name);


	}


}  