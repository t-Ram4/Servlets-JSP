package com.anathe.training.web;
import javax.servlet.http.*;  
import javax.servlet.*;  
import java.io.*; 
import javax.servlet.annotation.WebServlet;  

@WebServlet("/welcome")  
public class WelcomePageServlet extends HttpServlet{ 

 
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException  {  
	
	 	PrintWriter pw = res.getWriter();
		pw.println("<h2>hello from servlet</h2>");

	}


}  